<?php

use App\Http\Controllers\HomeController;
use App\Http\Controllers\MenuController;
use App\Http\Controllers\RestaurantController;

use Illuminate\Support\Facades\Auth;
use Illuminate\Support\Facades\Route;

/*
|--------------------------------------------------------------------------
| Web Routes
|--------------------------------------------------------------------------
|
| Here is where you can register web routes for your application. These
| routes are loaded by the RouteServiceProvider within a group which
| contains the "web" middleware group. Now create something great!
|
*/

// Route::get('/', function () {
//     return view('welcome');
// });

Auth::routes();

Route::get('', [HomeController::class, 'index'])->middleware('RedirectRestaurant')->name('index');

Route::get('restaurant/show/{restaurant:slug}', [RestaurantController::class, 'show'])->name('restaurant.show');

Route::middleware('auth')->group(function(){
    
    Route::middleware('CheckMaster')->group(function(){
        
        Route::prefix('restaurant')->group(function(){
            Route::get('create', [RestaurantController::class, 'create'])->name('restaurant.create');
            Route::post('store', [RestaurantController::class, 'store'])->name('restaurant.store');
            
            Route::get('edit/{restaurant:slug}', [RestaurantController::class, 'edit'])->name('restaurant.edit');
            Route::put('update/{restaurant:slug}', [RestaurantController::class, 'update'])->name('restaurant.update');
            Route::delete('delete/{restaurant:slug}', [RestaurantController::class, 'delete'])->name('restaurant.delete');
        });

    });


    Route::middleware('CheckMasterOrAdmin')->group(function(){

        Route::prefix('menu')->group(function(){
            Route::get('create/{restaurant:slug}', [MenuController::class, 'create'])->name('menu.create');
            Route::post('store/{restaurant:slug}', [MenuController::class, 'store'])->name('menu.store');

            Route::get('edit/{menu:id}', [MenuController::class, 'edit'])->name('menu.edit');
            Route::put('update/{menu:id}', [MenuController::class, 'update'])->name('menu.update');
            Route::delete('delete/{menu:id}', [MenuController::class, 'delete'])->name('menu.delete');
        });

    });

});

// Route::get('/home', [App\Http\Controllers\HomeController::class, 'index'])->name('home');

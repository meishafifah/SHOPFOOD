<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>SHOPFOOD : Website Pesan Antar Makanan Online</title>
    <link rel="stylesheet" href="<?php echo e(asset('assets/css/bootstrap.min.css')); ?>">
    <link rel="stylesheet" href="<?php echo e(asset('assets/css/style.css')); ?>">
    <link rel="stylesheet" href="<?php echo e(asset('assets/css/font.css')); ?>">
    <source src="<?php echo e(asset('assets/js/bootstrap.min.js')); ?>" type="">
    <link rel="icon" href="<?php echo e(asset('assets/img/fav-icon.svg')); ?>" type="image/x-icon">
</head>
<body class="account">
    <!-- navbar -->
    <section>
        <nav class="navbar navbar-expand-lg navbar-light bg-light">
            <div class="container">
              <a class="navbar-brand text-white righteous" href="#">
                  <img src="<?php echo e(asset('assets/img/logo-02.png')); ?>" alt="">
                  SHOPFOOD
              </a>
              <span>
                    <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarNav" aria-controls="navbarNav" aria-expanded="false" aria-label="Toggle navigation">
                      <span class="navbar-toggler-icon"></span>
                    </button>
                    <div class="collapse navbar-collapse" id="navbarNav">
                      <ul class="navbar-nav">
                        <li class="nav-item">
                          <a class="nav-link active text-white p400" aria-current="page" href="#">Beranda</a>
                        </li>
                        <li>
                          <?php if(auth()->guard()->guest()): ?>
                            <?php if(Route::has('register')): ?>
                              <a href="<?php echo e(route('register')); ?>" class="btn text-black">Daftar</a>
                            <?php endif; ?>

                            <?php if(Route::has('login')): ?>
                              <a href="<?php echo e(route('login')); ?>" class="btn text-black">Masuk</a>
                            <?php endif; ?>

                          <?php else: ?>
                              <a class="btn text-black" href="<?php echo e(route('logout')); ?>"
                                  onclick="event.preventDefault();
                                  document.getElementById('logout-form').submit();">
                                  <?php echo e(__('Logout')); ?>

                              </a>
                              <form id="logout-form" action="<?php echo e(route('logout')); ?>" method="POST" class="d-none">
                                  <?php echo csrf_field(); ?>
                              </form>  
                          <?php endif; ?>

                        </li>
                      </ul>
                </span>
            </div>
          </nav>
        </div>
    </section>

    <?php echo $__env->yieldContent('accountarea'); ?>

    <!-- footer -->
    <section>
        <footer>developed by SHOPFOOD</footer>
        </section>
    </body>
    </html><?php /**PATH /Applications/MAMP/htdocs/SHOPFOOD/resources/views/templates/account.blade.php ENDPATH**/ ?>
<?php $__env->startSection('content'); ?>
    <!-- hero -->
    <section class="hero">
        <div class="container">
            <div class="row">
                <div class="col-md-6 txt">
                    <h1 class="p-700 text-white" >SHOPFOOD</h1>
                    <p class="text-white">Kamu bingung mau makan apa hari ini? Coba deh kamu cek menu-menu enak dengan klik tombol dibawah ini</p>
                    <!--SEARCH-->
                    <form class="d-flex">
                        <input class="form-control me-2" type="text" placeholder="explore your favorit food">
                        <button class="btn text-black" type="button">search</button>
                      </form>
                </div>
                <div class="row col-md-6">
                    <img class="w-100" src="<?php echo e(asset('assets/img/driver.png')); ?>" alt="">
                </div>
            </div>
        </div>
    </section>

    <!-- Menu -->
    <section class="menu">
        <div class="block-hr">
            <h2>Participating Stores</h2>
        </div>
        <div class="container">
            
            <?php if(Auth::user()): ?>
                <?php if(Auth::user()->role == "master"): ?>
                    <a class="btn btn-kenyang" href=" <?php echo e(route('restaurant.create')); ?> ">Tambah restoran</a>
                <?php endif; ?>
            <?php endif; ?>

            <div class="row">
                <div class="col-md-12">
                        <h2 class="righteous text-dark"><span><img src="<?php echo e(asset('assets/img/line.png')); ?>" alt=""></span> Banyak Promo</h2>
                </div>
            </div>
            <div class="row">
                <?php $__currentLoopData = $restaurantPromo; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $restaurant): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <div class="col-md-3">
                        <a href="<?php echo e(route('restaurant.show', $restaurant->slug)); ?>">
                            <div class="card">
                                <img src="<?php echo e(asset('storage/'. $restaurant->picture)); ?>" class="card-img-top" alt="...">
                                <div class="card-body">
                                    <p class="card-text p-300">0.5 km</p>
                                    <h5 class="card-title p-700"><?php echo e($restaurant->name); ?></h5>
                                    <p class="card-text"><span><img class="star" src="<?php echo e(asset('assets/img/ic-star.png')); ?>" alt=""></span> <?php echo e($restaurant->rating); ?></p>
                                </div>
                                <?php if(Auth::user()): ?>
                                    <?php if(Auth::user()->role == 'master'): ?>
                                    <div class="d-flex mt-3">  
                                        <a href=" <?php echo e(route('restaurant.edit', $restaurant->slug)); ?> " class="btn btn-kenyang me-2">Edit</a>
                                        
                                        <form action="<?php echo e(route('restaurant.delete', $restaurant->slug)); ?> " method="post">
                                            <?php echo method_field('delete'); ?>
                                            <?php echo csrf_field(); ?>

                                            <button type="submit" class="btn btn-kenyang">Hapus</button>
                                        </form>
                                    </div> 
                                    <?php endif; ?>
                                <?php endif; ?>
                            </div>
                        </a>
                    </div>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </div>
                
            <div class="row">
                <div class="col-md-12">
                        <h2 class="righteous text-dark"><span><img src="<?php echo e(asset('assets/img/line.png')); ?>" alt=""></span> Toko Ter-Populer</h2>
                </div>
            </div>
            <div class="row">
                <?php $__currentLoopData = $restaurantPopuler; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $restaurant): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <div class="col-md-3">
                    <a href="<?php echo e(route('restaurant.show', $restaurant->slug)); ?>">
                        <div class="card">
                            <img src="<?php echo e(asset('storage/'. $restaurant->picture)); ?>" class="card-img-top" alt="...">
                            <div class="card-body">
                                <p class="card-text p-300">0.5 km</p>
                                <h5 class="card-title p-700"><?php echo e($restaurant->name); ?></h5>
                                <p class="card-text"><span><img class="star" src="<?php echo e(asset('assets/img/ic-star.png')); ?>" alt=""></span> <?php echo e($restaurant->rating); ?></p>
                            </div>
                            <?php if(Auth::user()): ?>
                            <?php if(Auth::user()->role == 'master'): ?>
                            <div class="d-flex mt-3">  
                                <a href=" <?php echo e(route('restaurant.edit', $restaurant->slug)); ?> " class="btn btn-kenyang me-2">Edit</a>
                                
                                <form action="<?php echo e(route('restaurant.delete', $restaurant->slug)); ?> " method="post">
                                    <?php echo method_field('delete'); ?>
                                    <?php echo csrf_field(); ?>

                                    <button type="submit" class="btn btn-kenyang">Hapus</button>
                                </form>
                            </div> 
                            <?php endif; ?>
                        <?php endif; ?>

                        </div>
                    </a>
                </div>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </div>
 
                <div class="row">
                <div class="col-md-12">
                        <h2 class="righteous text-dark"><span><img src="<?php echo e(asset('assets/img/line.png')); ?>" alt=""></span> Rekomendasi</h2>
                </div>
            </div>
            <div class="row">
                <?php $__currentLoopData = $restaurantRekomendasi; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $restaurant): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <div class="col-md-3">
                    <a href="<?php echo e(route('restaurant.show', $restaurant->slug)); ?>">
                        <div class="card">
                            <img src="<?php echo e(asset('storage/'. $restaurant->picture)); ?>" class="card-img-top" alt="...">
                            <div class="card-body">
                                <p class="card-text p-300">0.5 km</p>
                                <h5 class="card-title p-700"><?php echo e($restaurant->name); ?></h5>
                                <p class="card-text"><span><img class="star" src="<?php echo e(asset('assets/img/ic-star.png')); ?>" alt=""></span> <?php echo e($restaurant->rating); ?></p>
                            </div>
                            <?php if(Auth::user()): ?>
                            <?php if(Auth::user()->role == 'master'): ?>
                            <div class="d-flex mt-3">  
                                <a href=" <?php echo e(route('restaurant.edit', $restaurant->slug)); ?> " class="btn btn-kenyang me-2">Edit</a>
                                
                                <form action="<?php echo e(route('restaurant.delete', $restaurant->slug)); ?> " method="post">
                                    <?php echo method_field('delete'); ?>
                                    <?php echo csrf_field(); ?>

                                    <button type="submit" class="btn btn-kenyang">Hapus</button>
                                </form>
                            </div> 
                            <?php endif; ?>
                        <?php endif; ?>

                        </div>
                    </a>
                </div>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </div>
        </div>
    </section>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('templates.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /Applications/MAMP/htdocs/SHOPFOOD/resources/views/index.blade.php ENDPATH**/ ?>
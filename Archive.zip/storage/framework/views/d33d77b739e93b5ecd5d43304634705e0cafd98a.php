<?php $__env->startSection('content'); ?>
    <!-- info makanan -->
    <section class="toko">
        <div class="cover">
            <img class="w-100" src="<?php echo e(asset('storage/'. $restaurant->picture)); ?>" alt="">
        </div>
        <div class="container">
            <div class="row mt-4">
                <div class="col-md-7">
                    <h1 class="p-700 text-dark"><?php echo e($restaurant->name); ?></h1>
                    <p class="text-dark"><?php echo e($restaurant->description); ?></p>
                    <p class="text-dark">
                        <img src="<?php echo e(asset('assets/img/ic-star.png')); ?> " alt="">
                        <img src="<?php echo e(asset('assets/img/ic-star.png')); ?> " alt="">
                        <img src="<?php echo e(asset('assets/img/ic-star.png')); ?> " alt="">
                        <img src="<?php echo e(asset('assets/img/ic-star.png')); ?> " alt="">
                        <img src="<?php echo e(asset('assets/img/ic-star.png')); ?> " alt="">
                        <?php echo e($restaurant->rating); ?> (100+)
                    </p>
                </div>

                <div class="col-md-5">
                    <div class="kupon mb-2">
                        <h3 class="righteous">kode : MANTAPP</h3>
                    </div>
                    <p class="text-dark">masukkan kode MANTAP untuk mendapatkan diskon 30% , syarat dan ketentuan berlaku</p>
                </div>
            </div>

            <hr>

            
            <?php if(Auth::user()): ?>
                <?php if(Auth::user()->role == "master" || Auth::user()->role == 'admin'): ?>
                    <a class="btn btn-kenyang" href=" <?php echo e(route('menu.create', $restaurant->slug)); ?> ">Tambah menu</a>
                <?php endif; ?>
            <?php endif; ?>
        

            <div class="row mt-5">
                <?php $__currentLoopData = $menus; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item => $menu): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?> 
                    <div class="col-md-4">
                        <div class="block-menu">
                            <div class="row">
                                <div class="col-md-6">
                                    <img class="ic-menu" src="<?php echo e(asset('storage/'.$menu->picture)); ?>" alt="">
                                </div>
                                <div class="col-md-6 align-self-center">
                                    <h4><?php echo e($menu->name); ?></h4>
                                    <br>
                                    <h4 class="biru"><?php echo e($menu->price); ?></h4>
                                </div>
                            </div>
                            <p class="mt-2"><?php echo e($menu->description); ?></p>
                            <div class="row">
                                <?php if(Auth::user()): ?>
                                    <?php if(Auth::user()->role == 'master' || Auth::user()->role == 'admin'): ?>
                                    <div class="d-flex mt-3">  
                                        <a href=" <?php echo e(route('menu.edit', $menu->id)); ?> " class="btn btn-kenyang me-2">Edit</a>
                                        
                                        <form action="<?php echo e(route('menu.delete', $menu->id)); ?> " method="post">
                                            <?php echo method_field('delete'); ?>
                                            <?php echo csrf_field(); ?>

                                            <button type="submit" class="btn btn-kenyang">Hapus</button>
                                        </form>
                                    </div> 
                                    <?php else: ?> 
                                        <div class="col-md-8">
                                            <img src="img/ic-minus.png" alt="">
                                            <input type="number" >
                                            <img src="img/ic-plus.png" alt="">
                                        </div>
                                        <div class="col-md-4">
                                            <div class="btn">
                                                <img src="img/ic-cart.png" alt="">
                                            </div>
                                        </div>
                                    <?php endif; ?>
                                <?php endif; ?>
                            </div>
                        </div>
                    </div>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </div>
        </div>
    </section>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('templates.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /Applications/MAMP/htdocs/SHOPFOOD/resources/views/restaurant/show.blade.php ENDPATH**/ ?>